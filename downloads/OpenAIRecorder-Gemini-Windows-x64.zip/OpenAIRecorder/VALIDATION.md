# Validation — Gemini desktop 0.4

- 27 Rust tests passed. New coverage includes exact 60-second segmentation and final tails, automatic recovery of an interrupted full minute and partial tail, one-/two-model Gemini request contracts, Bulgarian transcript/notes persistence, required separate-notes selection after a capability failure, auth-error retention and explicit retry, idempotent persisted checkpoints, preserved user checkboxes/action identity, and key-file separation/removal. Test requests use an isolated local HTTP fixture with a fake key, not Google's service.
- WebRTC speech-indicator buffering and silence were tested. These checks do not establish VAD accuracy for real microphones/noise.
- Headless native panels/theme checks passed. The Gemini settings and compact-controls design preview were visually inspected in a Linux virtual display, together with sample Bulgarian notes/actions. The preview is not the actual Win32 popup.
- Linux and Windows Clippy with warnings denied passed, and the Windows x64 GUI-subsystem release cross-build passed. The cross-build includes HTTPS/rustls, DPAPI bindings, native WASAPI capture/playback, local WebRTC VAD, and DPI-aware compact controls. Archive contents/checksum and runtime dependencies were checked. Whisper, speech models, CLI agents, and end-user setup scripts are not included.
- No usable Gemini API key was supplied to this cloud. Actual Google authentication, selected-model audio/structured-output support, quotas, latency, and Bulgarian recognition quality are unverified. The app's Test audio & notes control performs that provider check on the user's computer.
- Physical Windows audio, DPAPI protection/unlocking, topmost dragging, DPI changes, control interaction, and the voice indicator have not run on Windows. Linux rendering, mock API tests, and cross-compilation do not prove that behavior.

## Library and recorder follow-up

The headless UI test now verifies that an updated library snapshot preserves unsaved notes in an open session, and clears its editor only after that session is successfully removed. Existing backend tests cover deletion and survival of copied global actions. Rounded Win32 owner-drawn buttons now clear their full rectangles, and keyboard focus uses a custom purple outline. Settings preview icons use matching vector geometry. This painting fix is cross-compiled, not physically verified on Windows.

Current Gemini model IDs, audio-input pricing, and the restricted availability of 2.5 were checked against Google's model catalog and pricing documentation on 2026-10-14. Suggested models are not proof of account access or recognition quality; account discovery and the audio/notes probe remain necessary. No live Gemini calls were made.

## Compact library and 30-day Archives

27 tests pass, including archive retention just before and exactly at 30 days, repeated archive idempotence, restore canceling expiry, removal of the complete session folder, survival of copied global actions, legacy metadata without an archive field, invalid/future dates, and active-recording protection. A headless layout regression renders 25 rows and asserts fixed horizontal position, row height, and sidebar width.

The compact native library was inspected in a Linux virtual display with isolated Bulgarian/English sample records. Pinning into the separate section, archive confirmation, archiving into the expandable folder, and restoration were exercised using pointer events. This is native Linux UI verification; physical Windows UI behavior remains unverified.

## Application icon and footer branding

The Windows release PE was inspected with llvm-readobj: it contains seven ICON resources and one GROUP_ICON resource. The ICO sizes (16, 24, 32, 48, 64, 128, 256) and the runtime 64×64 RGBA length were verified. Eframe receives the logo through the native viewport icon setting, which supplies its Windows title/taskbar icon setter. The footer link and its placement below Saved on this computer were visually inspected in the Linux native display. 27 tests, Linux/Windows Clippy with warnings denied, and the Windows release build passed. Actual Windows taskbar/Explorer appearance remains unverified on a physical Windows system.
